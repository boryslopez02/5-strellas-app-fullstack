<template>
    <div class="privacy py-5">
        <div class="container">
            <h1 class="text-center my-5">POLÍTICA DE PRIVACIDAD GDPR</h1>

            <div class="content">
                <p class="lead mb-3">Bienvenid@ a Imperatool.com te invitamos a conocer estos términos antes de facilitar tus datos personales.</p>

                <p class="lead my-3"><strong>Menores de edad</strong></p>

                <p class="lead">En el caso de los menores de trece años se requiere el consentimiento de los padres o tutores para el tratamiento de sus datos personales. En ningún caso se recabarán del menor de edad datos relativos a la situación profesional, económica o a la intimidad de los otros miembros de la familia, sin el consentimiento de éstos. Si eres menor de trece años y has accedido a este sitio web sin avisar a tus padres*no debes registrarte como usuario. Algunos principios que debes conocer En imperatool.com es una prioridad el respeto y la protección de los datos personales de los usuarios.</p>

                <p class="lead"><strong>Como usuario debes saber que tus derechos están garantizados en esta web.</strong> Nos hemos esforzado en crear un espacio seguro y confiable y por eso queremos compartir nuestros principios respecto a tu privacidad:</p>

                <ul class="list-group list-group-flush my-3">
                    <li class="list-group-item">Nunca se solicita información personal a menos que realmente sea necesaria para prestarte los servicios requeridos.</li>
                    <li class="list-group-item">Nunca compartimos información personal de usuarios con nadie, excepto para cumplir con la ley o en caso de que contemos con tu autorización expresa.</li>
                    <li class="list-group-item">Nunca utilizamos tus datos personales con una finalidad diferente a la expresada en esta política de privacidad. Esta Política de Privacidad podría variar en función de exigencias legislativas o de autorregulación, por lo que te aconsejo como usuario que la visites periódicamente. Será aplicable en caso de que los usuarios decidan rellenar cualquiera de sus formularios de contacto donde se recaben datos de carácter personal.</li>
                </ul>

                <p class="lead my-3"><strong>Regulaciones legales a las que se acoge esta web</strong></p>

                <p class="lead my-3">Imperatool.com adecuando esta web a las exigencias de la Ley Orgánica 15/1999, de 13 de diciembre, de Protección de Datos de Carácter Personal (LOPD), y al Real Decreto 1720/2007, de 21 de diciembre, conocido como el Reglamento de desarrollo de la LOPD. Cumple también con el Reglamento (UE) 2016/679 del Parlamento Europeo y del Consejo de 27 de abril de 2016 relativo a la protección de las personas físicas (RGPD), así como con la Ley 34/2002, de 11 de julio, de Servicios de la Sociedad de la Información y Comercio Electrónico (LSSICE o LSSI).</p>

                <p class="lead my-3">Responsable del tratamiento de tus datos personales Identidad del responsable:</p>

                <p class="lead"><strong>Responsable: Marco Lopez de Miguel</strong></p>

                <p class="lead"><strong>NIF/CIF: 49101456K</strong></p>

                <p class="lead"><strong>Dirección: C/Castillejos N6, 28944, Madrid</strong></p>

                <p class="lead"><strong>Email: hola@negocio5estrallas.com</strong></p>

                <p class="lead my-3"><strong>Actividad:</strong> Herramienta para la gestión y marketing de perfiles en redes sociales y Maps, teniendo como principal servicio Marketplace/punto de intercambio o encuentro de empresas y clientes para la mejora de su reputación online a partir de opiniones de usuarios reales de la plataforma. Pudiendo en todo momento los usuarios rechazar o aceptar la publicación del contenido facilitado por las empresas.</p>

                <p class="lead my-3">A efectos de lo previsto en el Reglamento General de Protección de Datos antes citado, los datos personales que nos facilite a través de los formularios de la web recibirán el tratamiento de datos de “Usuarios de la web y suscriptores”. Para el tratamiento de datos de nuestros usuarios hemos implementado todas las medidas técnicas y organizativas de seguridad establecidas en la legislación vigente.</p>

                <p class="lead my-3"><strong>¿Cómo hemos obtenido tus datos?</strong></p>

                <p class="lead my-3">Los datos personales que tratamos en Imperatool.com proceden de:</p>
                
                <ul class="list-group list-group-flush my-3">
                    <li class="list-group-item">Formulario de contacto.</li>
                    <li class="list-group-item">Formulario de registro.</li>
                    <li class="list-group-item">Registro de cuenta.</li>
                    <li class="list-group-item">Edición de datos de cuentas.</li>
                    <li class="list-group-item">Contratación de servicios.</li>
                    <li class="list-group-item">Emails recibidos.</li>
                </ul>

                <p class="lead my-3"><strong>¿Cuáles son tus derechos cuando nos facilitas tus datos?</strong></p>

                <p class="lead my-3">ualquier persona tiene derecho a obtener confirmación sobre si en Imperatool.com estamos tratando datos personales que nos conciernen o no. Las personas interesadas tienen derecho a: Solicitar el acceso a los datos personales relativos al interesado.</p>

                <ul class="list-group list-group-flush my-3">
                    <li class="list-group-item">Solicitar su rectificación o supresión.</li>
                    <li class="list-group-item">Solicitar la limitación de su tratamiento.</li>
                    <li class="list-group-item">Oponerse al tratamiento.</li>
                    <li class="list-group-item">Solicitar la portabilidad de los datos.</li>
                </ul>

                <p class="lead my-3">Los interesados podrán*acceder*a sus datos personales, así como a solicitar la*rectificación*de datos inexactos o, en su caso, a solicitar su*supresión*cuando, entre otros motivos, los datos ya no sean necesarios para los fines que fueron recogidos. En determinadas circunstancias, los interesados podrán solicitar la*limitación*del tratamiento de sus datos, en cuyo caso, únicamente serán conservados para el ejercicio o la defensa de reclamaciones. 
                <br><br>
                En determinadas circunstancias y por motivos relacionados con su situación particular, los interesados podrán*oponerse*al tratamiento de sus datos. Imperatool.com dejará de tratar los datos, salvo por motivos legítimos imperiosos, o el ejercicio o la defensa de posibles reclamaciones. También podrán solicitar la*portabilidad*de sus datos. Los interesados también tendrán derecho a la tutela judicial efectiva y a presentar una reclamación ante la autoridad de control, en este caso, la Agencia Española de Protección de Datos, si consideran que el tratamiento de datos personales que le conciernen infringe el Reglamento.   
                </p>

                <p class="lead my-3"><strong>¿Con qué finalidad tratamos sus datos personales?</strong></p>

                <p class="lead my-3">Cuando un usuario se conecta a nuestra web por ejemplo para registrarse, mandar un mensaje a través del contacto, abrir un chat de atención al cliente o realizar alguna contratación, está facilitando información de carácter personal de la que es responsable: Imperatool.com. Esa información puede incluir datos de carácter personal como pueden ser tu dirección IP, nombre, dirección física, dirección de correo electrónico, número de teléfono y otra información. Al facilitar esta información, el usuario da su consentimiento para que su información sea recopilada, utilizada, gestionada y almacenada por Imperatool.com sólo como se describe en el*Aviso Legal*y en la presente*Política de Privacidad. En Imperatool.com existen diferentes sistemas de captura de información personal y tratamos la información que nos facilitan las personas interesadas con el siguiente fin por cada sistema de captura (formularios):</p>

                <ul class="list-group list-group-flush my-3">
                    <li class="list-group-item"><strong>Formulario de contacto:</strong> *Solicitamos los siguientes datos personales: nombre, email, para responder a los requerimientos de los usuarios de*Imperaool.com. Por ejemplo, podemos utilizar esos datos para responder a tu solicitud y dar respuesta a las dudas, quejas, comentarios o inquietudes que puedas tener relativas a la información incluida en la web, los servicios que se prestan a través de la web, el tratamiento de sus datos personales, cuestiones referentes a los textos legales incluidos en la web, así como cualesquiera otras consultas que pueda tener y que no estén sujetas a las condiciones de contratación. <br>Informamos que los datos que nos facilitas estarán ubicados en los servidores de OVH, S.A.S. (proveedor de hosting de Imperatool.com) dentro de la UE.</li>
                    <li class="list-group-item"><strong>Formulario de venta:</strong> *El usuario dispone de diferentes formularios de compra sujetos a las condiciones de contratación especificadas en mis*condiciones de contratación*particulares para cada producto o servicio donde se te requerirán datos de contacto y de pago. Solicitamos los siguientes datos personales según si es empresa o particular: nombre y apellido o nombre de empresa, CIF/NIF, email, dirección, datos de facturación. Te informo que los datos que nos facilitas estarán ubicados en los servidores de OVH, S.A.S.(proveedor de hosting de Imperatool.com) dentro de la UE.</li>
                    <li class="list-group-item"><strong>Formulario de suscripción a contenidos:</strong> *En este caso, solicitamos los siguientes datos personales: nombre, email, para gestionar la lista de suscripciones, enviar boletines, promociones y ofertas especiales, facilitados por el usuario al realizar la suscripción. Dentro de la web existen varios formularios para activar la suscripción, el uso de un servicio al facilitar más datos incluye la suscripción. Los boletines electrónicos o newsletters están gestionados por Amazon Web Services EMEA SARL. Al utilizar los servicios de esta plataforma para la realización de campañas de marketing por correo electrónico, gestión de suscripciones y envío de boletines, debes saber que Amazon Web Services EMEA SARL tiene sus servidores alojados en Luxemburgo país dentro de la unión Europea.</li>
                    <li class="list-group-item"><strong>Formulario de alta para comentarios del blog (Blog en construcción y formulario aún no disponible que se regirá por este aviso):</strong> *Para comentar las publicaciones del blog de Imperatool.com se requiere que el usuario se dé de alta a través de este formulario. En este caso, solicito los siguientes datos personales: nombre, email, sitio web.*Una vez dado de alta, el usuario podrá realizar tantos comentarios como desee y dar respuesta sobre los anteriores.*Te informo que los datos que me facilitas estarán ubicados en los servidores de OVH, S.A.S. (proveedor de hosting de Imperatool.com) dentro de la UE.</li>
                    <li class="list-group-item"><strong>Formulario de alta para comentarios del blog (Blog en construcción y formulario aún no disponible que se regirá por este aviso):</strong>Formulario de registro de cuenta:*En este caso, solicito los siguientes datos personales: nombre, email, para gestionar el alta de registro de tu cuenta a Imperatool. Le informamos que los datos que nos facilitas estarán ubicados en los servidores de OVH, S.A.S. (proveedor de hosting de Imperatool.com) dentro de la UE. Existen otras finalidades por la que trato tus datos personales: Para garantizar el cumplimiento de las condiciones de uso y la ley aplicable. Esto puede incluir el desarrollo de herramientas y algoritmos que ayudan a esta web a garantizar la confidencialidad de los datos personales que recoge. Para apoyar y mejorar los servicios que ofrece esta web. También se recogen otros datos no identificativos que se obtienen mediante algunas cookies que se descargan en el ordenador del usuario cuando navega en esta web que detallo en la*política de cookies. Para gestionar las redes sociales. Imperatool.com puede tener presencia en redes sociales. El tratamiento de los datos que se lleve a cabo de las *personas que se hagan seguidoras en las redes sociales de las páginas oficiales de Imperatool.com, se regirá por este apartado. Así como por aquellas condiciones de uso, políticas de privacidad y normativas de acceso que pertenezcan a la red social que proceda en cada caso y aceptadas previamente por el usuario de Imperatool.com.*Tratará sus datos con las finalidades de administrar correctamente su presencia en la red social, informando de actividades, productos o servicios de Imperatool.com. *Así como para cualquier otra finalidad que las normativas de las redes sociales permitan. Imperatool.com no vende, alquila ni cede datos de carácter personal que puedan identificar al usuario, ni lo hará en el futuro, a terceros sin el consentimiento previo. Sin embargo, en algunos casos se pueden realizar colaboraciones con otros profesionales o empresas, en esos casos, se requerirá consentimiento a los usuarios informando sobre la identidad del colaborador y la finalidad de la colaboración. Siempre se realizará con los más estrictos estándares de seguridad. Legitimación para el tratamiento de tus datos La base legal para el tratamiento de sus datos es:*el consentimiento.</li>
                </ul>

                <p class="lead my-3">Para contactar o realizar comentarios en esta web se requiere el consentimiento con esta política de privacidad. La oferta prospectiva o comercial de productos y servicios está basada también en el consentimiento que se le solicita, sin que en ningún caso la retirada de este consentimiento condicione la ejecución del contrato de suscripción. También la contratación de productos y servicios *según los términos y condiciones que constan en la*política comercial.</p>

                <p class="lead my-3"><strong>¿Por cuánto tiempo conservaremos tus datos?</strong></p>

                <p class="lead">Los datos personales proporcionados se conservarán:</p>

                <ul class="list-group list-group-flush my-3">
                    <li class="list-group-item">Mientras se mantenga la relación mercantil.</li>
                    <li class="list-group-item">No se solicite su supresión por parte del interesado.</li>
                </ul>

                <p class="lead my-3"><strong>¿A qué destinatarios se comunicarán tus datos?</strong></p>

                <p class="lead my-3">Para prestar servicios estrictamente necesarios para el desarrollo de la actividad, Imperatool.com, comparte datos con los siguientes prestadores bajo sus correspondientes condiciones de privacidad. Todas las utilidades ofrecidas por terceros son estrictamente necesarias para el desarrollo de nuestros servicios y han sido seleccionadas atendiendo al cumplimiento de los derechos que se preservan en esta web. Las siguientes empresas tendrán acceso a la información personal necesaria para realizar sus funciones como encargados de tratamiento, pero no podrán utilizarla para otros fines. Además, deberán tratar la información personal de conformidad con la presente Política de Privacidad y la legislación aplicable en materia de protección de datos.</p>

                <p class="lead my-3"><strong>Hosting:</strong> OVH,S.A.S, con domicilio en 2 rue Kellermann - 59100 Roubaix - France. Más información en <a href="">https://www.ovh.com/fr/support/mentions-legales/</a> OVH.SAS trata los datos con la finalidad de realizar sus servicios como proveedor de hosting a Imperatool.com</p>

                <p class="lead my-3"><strong>Gestor de base de datos:</strong> mLab, con domicilio en 660 York St, Ste 101, San Francisco, CA 94110. Más información en <a href="">https://mlab.com/company/</a> trata los datos con la finalidad de realizar sus servicios como proveedor de servicio de base de datos a Imperatool.com. Cumpliendo con todas las garantías de la ley GDRP Europea, más información: https://docs.mlab.com/eu-data-protection/</p>

                <p class="lead my-3"><strong>Email marketing:</strong> Amazon Web Services EMEA SARL (AWS Europe), con domicilio en Luxemburgo. Más información <a href="">https://aws.amazon.com/es/tax-help/european-union/</a> Amazon Web Services EMEA SARL (AWS Europe) trata los datos con la finalidad de realizar sus servicios de gestión de email marketing a Imperatool.com.</p>

                <p class="lead my-3"><strong>Email Inbox:</strong> YANDEX LLC, con domicilio en Ulitsa Lva Tolstogo 16, Moscow, Russia 119021. Más información <a href="">https://yandex.com/legal/privacy/</a> YANDEX LLC trata los datos con la finalidad de realizar sus servicios de gestión de recepción de emails.</p>
               
                <p class="lead my-3"><strong>Chat de soporte:</strong> tawk.to inc., con domicilio 187 East Warm Springs Rd, SB119, Las Vegas, NV, 89119. Cumple con la legislación europea GDPR. Más información: <a href="">https://www.tawk.to/data-protection/gdpr/</a></p>

                <p class="lead my-3"><strong>Asesoría/Gestoría:</strong> ContaSimple S.L, con domicilio C/Travessera de les Corts, 340 Entlo 3ª, 08029 Barcelona dentro de la Unión Europea. Cumple con la legislación europea GDPR. Más información: <a href="">https://www.contasimple.com</a></p>

                <p class="lead my-3"><strong>Datos de navegación</strong></p>

                <p class="lead my-3">Al navegar por Imperatool.com se pueden recoger datos no identificables, que pueden incluir, direcciones IP, ubicación geográfica (aproximadamente), un registro de cómo se utilizan los servicios y sitios, y otros datos que no pueden ser utilizados para identificar al usuario. Entre los datos no identificativos están también los relacionados a tus hábitos de navegación a través de servicios de terceros.</p>

                <p class="lead my-3"><strong>Google Analytics:</strong> un servicio analítico de web prestado por Google, Inc., una compañía de Delaware cuya oficina principal está en 1600 Amphitheatre Parkway, Mountain View (California), CA 94043, Estados Unidos (“Google”). Google Analytics utiliza “cookies”, que son archivos de texto ubicados en tu ordenador, para ayudar a Imperatool.com a analizar el uso que hacen los usuarios del sitio web.
                <br><br>
                <strong>Facebook Analytics:</strong> un servicio analítico de web prestado por Google, Inc., una compañía de Delaware cuya oficina principal está en 1600 Amphitheatre Parkway, Mountain View (California), CA 94043, Estados Unidos (“Google”). Google Analytics utiliza “cookies”, que son archivos de texto ubicados en tu ordenador, para ayudar a Imperatool.com a analizar el uso que hacen los usuarios del sitio web.
                <br><br>
                La información que genera la cookie acerca de su uso de Imperatool.com (incluyendo tu dirección IP) será directamente transmitida y archivada por Facebook y Google en los servidores de Estados Unidos.
                <br><br>
                <strong>Facebook/Google Login:</strong> atendiendo a la completitud de la información para aquellos usuarios que elijan la opción de Login a través de estas redes sociales solo se obtendrá la información básica, nombre, apellido y email.
                <br><br>
                Esta web utiliza los siguientes servicios de análisis de terceros:
                <br><br>
                <strong>Google Analytics y Facebook Analitycs.</strong> Search Console. Utilizamos esta información para analizar tendencias, administrar el sitio, rastrear los movimientos de los usuarios alrededor del sitio y para recopilar información demográfica sobre nuestra base de usuarios en su conjunto. Tus derechos al facilitar tus datos personales:
                </p>

                <ul class="list-group list-group-flush my-3">
                    <li class="list-group-item">Cualquier persona tiene derecho a obtener confirmación sobre si en Imperatool.com se están tratando datos personales que les conciernan, o no.</li>
                    <li class="list-group-item">Las personas interesadas tienen derecho a acceder a sus datos personales, así como a solicitar la rectificación de los datos inexactos o, en su caso, solicitar su supresión cuando, entre otros motivos, los datos ya no sean necesarios para los fines que fueron recogidos.</li>
                    <li class="list-group-item">En determinadas circunstancias, los interesados podrán solicitar la limitación del tratamiento de sus datos, en cuyo caso únicamente los conservaremos para el ejercicio o la defensa de reclamaciones.</li>
                    <li class="list-group-item">En determinadas circunstancias y por motivos relacionados con su situación particular, los interesados podrán oponerse al tratamiento de sus datos. Imperatool.com dejará de tratar los datos, salvo por motivos legítimos imperiosos, o el ejercicio o la defensa de posibles reclamaciones. Podrá ejercitar materialmente sus derechos por correo electrónico a info@Imperatool.com.</li>
                </ul>

                <p class="lead my-3">
                    <strong>Secreto y seguridad de los datos</strong>
                    <br>
                    Imperatool.com se compromete en el uso y tratamiento de los datos personales incluidos de los usuarios, respetando su confidencialidad y a utilizarlos de acuerdo con la finalidad de los mismos, así como a dar cumplimiento a su obligación de guardarlos y adaptar todas las medidas para evitar la alteración, pérdida, tratamiento o acceso no autorizado (Como los protocolos Https que utilizamos o la encriptación de contraseñas), de conformidad con lo establecido en la normativa vigente de protección de datos. Imperatool.com no puede garantizar la absoluta inexpugnabilidad de la red de Internet y por tanto, la violación de los datos mediante accesos fraudulentos a ellos por parte de terceros.
                    <br><br>
                    <strong>Exactitud y veracidad de los datos</strong>
                    <br>
                    Como usuario, eres el único responsable de la veracidad y corrección de los datos que remitas a*Imperatool.com exonerando a*Imperatool.com, de cualquier responsabilidad al respecto. Los usuarios garantizan y responden, en cualquier caso, de la exactitud, vigencia y autenticidad de los datos personales facilitados y se comprometen a mantenerlos debidamente actualizados. El usuario acepta proporcionar información completa y correcta en el formulario de contacto o registro.
                    <br><br>
                    <strong>Aceptación y consentimiento</strong>
                    <br>
                    El usuario declara haber sido informado de las condiciones sobre protección de datos de carácter personal, aceptando y consintiendo el tratamiento de los mismos por parte de*Imperatool.com en la forma y para las finalidades indicadas en esta política de privacidad.
                    <br><br>
                    <strong>Cambios en la política de privacidad</strong>
                    <br>
                    Imperatool.com, se reserva el derecho a modificar la presente política para adaptarla a novedades legislativas o jurisprudenciales, así como a prácticas de la industria. En dichos supuestos, el Prestador anunciará en esta página los cambios introducidos con razonable antelación a su puesta en práctica.
                    <br><br>
                    <strong>Correos comerciales</strong>
                    <br>
                    De acuerdo con la LSSICE,*Imperatool.com no realiza prácticas de SPAM, por lo que no envía correos comerciales por vía electrónica que no hayan sido previamente solicitados o autorizados por el usuario. En consecuencia, en cada uno de los formularios habidos en la web, el usuario tiene la posibilidad de dar su consentimiento expreso para recibir emails, con independencia de la información comercial puntualmente solicitada. Conforme a lo dispuesto en la Ley 34/2002 de Servicios de la Sociedad de la Información y de comercio electrónico,*Imperatool.com se compromete a no enviar comunicaciones de carácter comercial sin identificarlas debidamente.
                    <br><br>
                    <strong>Documento revisado y en cumplimiento de las leyes españoles y europeas a 6 de Febrero de 2019.</strong>
                </p>
            </div>
        </div>
    </div>
</template>