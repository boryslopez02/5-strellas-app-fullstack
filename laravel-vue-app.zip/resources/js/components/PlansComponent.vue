<template>
    <div class="our-plans py-5" id="plans">
        <div class="row container justify-content-center justify-content-lg-start my-0 mx-auto px-0 py-5">
            <div class="col-12 text-white text-center my-5">
                <h1>Nuestros planes</h1>
            </div>
            <div class="col-10 col-sm-8 col-md-6 col-lg-4 p-0 basic">
                <div class="card">
                    <div class="card-body">
                        <div class="card-head d-flex align-items-center mt-2 mb-4">
                            <img src="img/icons/plans/1.star.png" class="mr-3">
                            <h4>BASIC</h4>
                        </div>
                        <h5 class="price d-flex align-items-center"><span class="mr-2">€</span>19</h5>
                        <ul>
                            <li>
                                <img src="img/icons/plans/checkbox-dark.png">
                                <p>10 RESEÑAS + LOCAL SEO</p>
                            </li>
                            <li>
                                <img src="img/icons/plans/checkbox-dark.png">
                                <p>Usuarios reales y geolocalizados</p>
                            </li>
                            <li>
                                <img src="img/icons/plans/checkbox-dark.png">
                                <p>Incluye Local Guides</p>
                            </li>
                            <li>
                                <img src="img/icons/plans/checkbox-dark.png">
                                <p>Eliges: Nº⭐, Texto, Imágenes y ⚤</p>
                            </li>
                            <li>
                                <img src="img/icons/plans/checkbox-dark.png">
                                <p>🔍 Monitoriza 5 Palabras Clave</p>
                            </li>
                            <li>
                                <img src="img/icons/plans/checkbox-dark.png">
                                <p>Calculadora de puntuación</p>
                            </li>
                            <li>
                                <img src="img/icons/plans/checkbox-dark.png">
                                <p>📈 Análisis SEO del perfil*</p>
                            </li>
                            <li>
                                <img src="img/icons/plans/checkbox-dark.png">
                                <p>💬 Asistencia prioritaria con técnicos</p>
                            </li>
                        </ul>
                        <a href="" class="btn btn-dark btn-block">Obtener plan</a>
                    </div>
                </div>
            </div>

            <div class="col-10 col-sm-8 col-md-6 col-lg-4 p-0 my-5 my-md-0 vip">
                <div class="card">
                    <div class="card-body">
                        <div class="card-head d-flex align-items-center mt-2 mb-4">
                            <img src="img/icons/plans/2.heart.png" class="mr-3">
                            <h4>VIP</h4>
                        </div>
                        <h5 class="price d-flex align-items-center"><span class="mr-2">€</span>49</h5>
                        <ul>
                            <li>
                                <img src="img/icons/plans/checkbox.png">
                                <p>10 RESEÑAS + LOCAL SEO</p>
                            </li>
                            <li>
                                <img src="img/icons/plans/checkbox.png">
                                <p>Usuarios reales y geolocalizados</p>
                            </li>
                            <li>
                                <img src="img/icons/plans/checkbox.png">
                                <p>Incluye Local Guides</p>
                            </li>
                            <li>
                                <img src="img/icons/plans/checkbox.png">
                                <p>Eliges: Nº⭐, Texto, Imágenes y ⚤</p>
                            </li>
                            <li>
                                <img src="img/icons/plans/checkbox.png">
                                <p>🔍 Monitoriza 5 Palabras Clave</p>
                            </li>
                            <li>
                                <img src="img/icons/plans/checkbox.png">
                                <p>Calculadora de puntuación</p>
                            </li>
                            <li>
                                <img src="img/icons/plans/checkbox.png">
                                <p>📈 Análisis SEO del perfil*</p>
                            </li>
                            <li>
                                <img src="img/icons/plans/checkbox.png">
                                <p>💬 Asistencia prioritaria con técnicos</p>
                            </li>
                        </ul>
                        <a href="" class="btn btn-dark btn-block">Obtener plan</a>
                    </div>
                </div>
            </div>

            <div class="col-10 col-sm-8 col-md-6 col-lg-4 p-0 my-md-5 my-lg-0 gold">
                <div class="card">
                    <div class="card-body">
                        <div class="card-head d-flex align-items-center mt-2 mb-4">
                            <img src="img/icons/plans/3.crown.png" class="mr-3">
                            <h4>GOLD</h4>
                        </div>
                        <h5 class="price d-flex align-items-center"><span class="mr-2">€</span>98</h5>
                        <ul>
                            <li>
                                <img src="img/icons/plans/checkbox-dark.png">
                                <p>10 RESEÑAS + LOCAL SEO</p>
                            </li>
                            <li>
                                <img src="img/icons/plans/checkbox-dark.png">
                                <p>Usuarios reales y geolocalizados</p>
                            </li>
                            <li>
                                <img src="img/icons/plans/checkbox-dark.png">
                                <p>Incluye Local Guides</p>
                            </li>
                            <li>
                                <img src="img/icons/plans/checkbox-dark.png">
                                <p>Eliges: Nº⭐, Texto, Imágenes y ⚤</p>
                            </li>
                            <li>
                                <img src="img/icons/plans/checkbox-dark.png">
                                <p>🔍 Monitoriza 5 Palabras Clave</p>
                            </li>
                            <li>
                                <img src="img/icons/plans/checkbox-dark.png">
                                <p>Calculadora de puntuación</p>
                            </li>
                            <li>
                                <img src="img/icons/plans/checkbox-dark.png">
                                <p>📈 Análisis SEO del perfil*</p>
                            </li>
                            <li>
                                <img src="img/icons/plans/checkbox-dark.png">
                                <p>💬 Asistencia prioritaria con técnicos</p>
                            </li>
                        </ul>
                        <a href="" class="btn btn-dark btn-block">Obtener plan</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    
}
</script>
