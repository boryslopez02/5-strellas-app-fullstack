<template>
    <footer class="footer py-4">
        <div class="row container mx-auto my-0 p-0 align-items-center justify-content-center">
            <div class="col-12 col-lg-5 d-flex flex-column flex-sm-row align-items-center text-center">
                <a href="faqs" class="mx-auto mx-lg-0">Preguntas frecuentes</a>
                <a href="" class="mx-auto my-3 my-sm-0 mx-lg-0 ml-lg-3">Términos y condiciones</a>
            </div>
            <div class="col-12 col-md-6 col-lg-3 mt-4 mt-lg-0">
                <div class="contain d-flex align-items-center justify-content-center p-2 mx-auto">
                    <img src="img/icons/footer/1.phone.png" class="mr-2">
                    <p class="m-0">+1 618 847 0531</p>
                </div>
            </div>
            <div class="col-12 col-md-6 col-lg-4 mt-4 mt-lg-0">
                <div class="contain d-flex align-items-center justify-content-center p-2 mx-auto">
                    <img src="img/icons/footer/2.mail.png" class="mr-2">
                    <p class="m-0">hola@negocio5estrallas.com</p>
                </div>
            </div>
        </div>
    </footer>
</template>

<script>
export default {

}
</script>