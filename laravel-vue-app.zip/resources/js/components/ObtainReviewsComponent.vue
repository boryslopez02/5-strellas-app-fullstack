<template>
    <div class="obtain-reviews py-5">
        <span class="glass"></span>
        <div class="row container align-items-center justify-content-center justify-content-lg-between my-0 mx-auto p-0">
            <div class="col-12 col-sm-10 col-md-6 main-text my-lg-5">
                <h1>Obtén reseñas positivas en Google My Business</h1>
                <p class="lead my-4">Con usuarios reales y geolocalizados</p>
                <div class="card p-3 mx-auto mx-md-0">
                    <p class="lead mb-1">Puedes elegir:</p>
                    <div class="d-flex justify-content-between">
                        <div class="box d-flex align-items-center">
                            <input type="checkbox" checked>
                            <p class="lead my-0 ml-2">Nº de Estrellas</p>
                        </div>
                        <div class="box d-flex align-items-center">
                            <input type="checkbox" checked>
                            <p class="lead my-0 ml-2">Imágenes</p>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between">
                        <div class="box d-flex align-items-center">
                            <input type="checkbox" checked>
                            <p class="lead my-0 ml-2">Texto</p>
                        </div>
                        <div class="box d-flex align-items-center">
                            <input type="checkbox" checked>
                            <p class="lead my-0 ml-2">Sexo</p>
                        </div>
                    </div>
                </div>
                <a href="/register" class="btn btn-warning mx-auto mx-md-0 mt-4">Recibe tu primera reseña gratis <span></span></a>
            </div>

            <div class="col-12 col-sm-10 col-md-6">
                <img src="img/hamburger.png" class="main-img img-fluid">
            </div>
        </div>
    </div>    
</template>

<script>
export default {

}
</script>