<template>
    <div class="faqs py-5">
        <div class="glass"></div>
        <div class="container">
            <h1 class="text-center my-5">PREGUNTAS FRECUENTES</h1>

            <div class="accordion" id="accordionExample">
                <div class="card">
                    <div class="header" id="headingOne">
                        <h2 class="mb-0">
                            <button class="btn btn-block business text-left" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                Empresa
                            </button>
                        </h2>
                    </div>

                    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                        <div class="card-body">
                            <h2>✚ Reseñas</h2>
                            <h3 class="my-3">¿Qué garantía tienen?</h3>
                            <p class="lead">Todas las reseñas que compres tienen <strong>6 meses de garantía</strong> desde su publicación. Si por cualquier motivo la reseña no se publica correctamente o fuera ocultada se asegura la reposición de la misma.</p>

                            <h3 class="my-3">¿Dónde puedo enviar las publicaciones?</h3>
                            <p class="lead">Tras adjuntar su perfil o perfiles y desde el mismo panel principal podrá añadir sus publicaciones haciendo click en <strong>"+ Nueva Reseña"</strong>, podrá ver el menú mostrado a continuación.</p>

                            <img src="img/faqs/faqs1.jpg" class="img-fluid d-block mx-auto my-4">

                            <h3 class="my-3">¿Cómo puedo llevar un control de las publicaciones publicadas y programadas?</h3>
                            <p class="lead">Al acceder al perfil de negocio deseado podrá ver el historial de todas sus publicaciones tanto de las programadas como de las ya publicadas.</p>

                            <img src="img/faqs/faqs2.jpg" class="img-fluid d-block mx-auto my-4">

                            <h3 class="my-3">Tengo varios locales, ¿puedo añadir varios en una misma cuenta?</h3>
                            <p class="lead"><strong>Sí</strong> tras crear su cuenta de forma sencilla puede <strong>añadir tantos perfiles como desee</strong>. Tras esto podrá contratar el pack deseado para cada perfil de forma individual o dividir un pack entre los perfiles añadidos.</p>

                            <img src="img/faqs/faqs3.png" class="img-fluid d-block mx-auto my-4">

                            <h3 class="my-3">Preciso de comprar packs mayores</h3>
                            <p class="lead">En caso de precisar de la contratación de packs mayores puede realizarlo de 2 formas, puede contratar la suscripción de Imperator para obtener las ventajas de todas nuestras herramientas y posteriormente dentro de su panel comprar más reseñas en el apartado "Tienda", esta forma le permite comenzar a trabajar de forma inmediata. También, puede ponerse en contacto con nosotros a través de nuestro formulario e indicar la necesidad de su negocio y el porque precisa de la asistencia directa de un agente para comenzar a trabajar, esto nos ayudará día a día.</p>

                            <img src="img/faqs/faqs4.png" class="img-fluid d-block mx-auto my-4">

                            <h3 class="my-3">¿Tienen opciones sin suscripción?</h3>
                            <p class="lead">Nuestros packs incluyen herramientas que le ayudarán a posicionar y superar a su competencia y se ofrecen con nuestra suscripción de forma gratuita por lo que el precio no varía. En cualquier caso, si desea realizar solo reseñas de forma individual esto es posible, para ello solo ha de registrarse en nuestro panel y acceder al apartado "Tienda" desde el cual podrá adquirir reseñas de forma individual. A pesar de esto, siempre recomendamos la suscripción ya que no tiene permanencia y ofrece muchas herramientas adicionales.</p>

                            <img src="img/faqs/faqs5.png" class="img-fluid d-block mx-auto my-4">

                            <h3 class="my-3">¿Puedo obtener reseñas gratis?</h3>
                            <p class="lead">Sí, puesto que nuestro sistema es un marketplace entre empresas y usuarios de Maps, puede crear su cuenta como "ambas", reseñador y empresa. Para poder conseguir reseñas gratuitas tan solo tendrá que utilizar sus perfiles para obtener créditos suficientes para comenzar a publicar en su propio.</p>

                            <h3 class="my-3">¿Puede Google penalizar mi perfil por comprar reseñas en Imperatool?</h3>
                            <p class="lead">Las reseñas son publicadas por usuarios reales, por este motivo no hay ninguna razón por la que Google pueda tomar medidas contra tu perfil. Estas opiniones son exactamente iguales que las que publican tus clientes habitualmente por lo que es 100% seguro comprar reseñas en Imperatool.</p>

                            <h3 class="my-3">¿Los usuarios que publican las opiniones son de la misma zona que mi negocio?</h3>
                            <p class="lead">A la hora de publicar las opiniones se seleccionan perfiles que coincidan con la localización de tu negocio para que las reseñas tengan un mayor valor para Google.</p>

                            <h3 class="my-3">¿Cómo funciona la geolocalización?</h3>
                            <p class="lead">Actualmente el sistema implementado se denomina "best effort" lo que implica que durante las primeras 24 horas de programar una reseña se tratará de buscar un perfil de usuario que encaje de la forma más precisa a la geolocalización indicada al añadir la reseña. En caso de no ser posible se pasará a buscar un perfil del mismo país y en último caso se obviará la geolocalización. Es necesario tener en cuenta que las cuentan se geolocalizan según la información que introducen los "reseñadores" por lo que se encuentra sujeta a lo fijado por estos usuarios. <strong>No siempre y en todos los casos será posible que sea geolocalizada. También es necesario tener en cuenta que la mayoría de usuarios son de origen hispanohablante.</strong></p>

                            <h3 class="my-3">¿Son usuarios Local Guides?</h3>
                            <p class="lead">Un porcentaje importante de los usuarios son Local Guide de al menos nivel 4. Instamos a nuestros usuarios a mejorar su nivel de Local Guide por lo que es posible que, si la cuenta que ha publicado una opinión en tu perfil no es Local Guide en ese momento, en unos días o semanas aumente su nivel y se convierta en Local Guide. <strong>No se asegura el obtener o no local guides.</strong>.</p>

                            <h3 class="my-3">¿Es posible que se oculten reseñas?</h3>
                            <p class="lead">Esto es posible ya que existen mecanismos automáticos que pueden ocultar publicaciones, nadie puede asegurar que se queden al 100%.</p>

                            <h3 class="my-3">¿Puedo publicar imágenes junto a las reseñas?</h3>
                            <p class="lead">Sí, al añadir su reseña podrá añadir imagenes a la misma. Tenga en cuenta que el algoritmo de Google podría filtrar la imagen por múltiples motivos y no aparecer esta cuando un usuario la publique, por lo que la publicación de la imagen no está garantizada.</p>

                            <img src="img/faqs/faqs6.png" class="img-fluid d-block mx-auto my-4">

                            <h3 class="my-3">¿Pueden los usuarios eliminar publicaciones?</h3>
                            <p class="lead">Contamos con mecanismos suficientes para asegurar la permanencia y sustitución en caso de que un usuario eliminara una publicación. Todos los usuarios deben cumplir estrictos requisitos, su cuenta podría ser cerrada inmediatamente y reclamados los pagos en caso de detectar que el borrado haya sido deliberado y voluntario. Además, contamos con una amplia garantía de 6 meses que le protege en estos casos.</p>

                            <h2>✚ Generales</h2>

                            <h3 class="my-3">¿Qué es Imperatool?</h3>
                            <p class="lead">Imperatool es una herramienta de local seo orientada a la mejora del posicionamiento, reputación online e ingresos permitiendo conseguir opiniones totalmente reales y ofreciendo herramientas útiles de gestión para el marketing y seo local. Imperatool no es una consultora, ofrecemos servicios autogestionados por el cliente proporcionándole herramientas que simplifican al mínimo el esfuerzo requerido. Muchas agencias utilizan nuestras herramientas para gestionar el marketing local de las cuentas de Google My Business.</p>

                            <h3 class="my-3">¿Qué diferencia hay entre el soporte chat con técnicos (pack Imperatool exclusivamente) y el de atención al cliente?</h3>
                            <p class="lead">La atención al cliente puede ayudarle en la navegación, facilitar información y ayudarle con los sistemas de pago. El soporte por técnicos (Solo disponible con el pack mensual Imperator) es una <strong>atención al cliente premium por parte de personal única y exclusivamente cualificado con estudios mínimos de "Ingeniero Informático"</strong> titulación concedida y reconocida por la universidad competente, con titulación certificada. Las dudas y preguntas son atendidas sin límite a través de nuestro email y derivadas a los expertos.</p>

                            <h3 class="my-3">¿Dónde puedo descargar mi factura?</h3>
                            <p class="lead">Todos los pedidos son facturados y puede obtener su factura del apartado correspondiente de su panel. Para que el sistema pueda tener su factura disponible es preciso que introduzca o nos facilite por contacto los siguientes detalles: Nombre de Empresa, CIF/NIF, Dirección.</p>

                            <h3 class="my-3">¿Cuentan con asistencia telefónica?</h3>
                            <p class="lead">Contamos con asistencia por chat y email. Además, pueden consultar con nuestros ingenieros en caso de contar con el pack superior. Para poder mantener el precio de nuestro servicio no es posible ofrecer asistencia telefónica, en caso de desear servicios de consultoría o asistencia puede ponerse en contacto para consultar los precios con nuestra consultora asociada Tech-Solutio, puede consultar los servicios y precios en su página web.</p>

                            <h2>✚ Herramientas Local Seo</h2>
                            
                            <h3 class="my-3">¿Qué significa monitorizar palabras clave?</h3>
                            <p class="lead">La monitorización de palabras clave te permite ver la mejora en el tiempo de tu posicionamiento entre tus competidores. Mejor posicionamiento implica más clientes. Podrás monitorizar palabras clave como "restaurantes barrio la latina", "mejor marisquería madrid" y te ayudaremos para que puedas ganar posiciones para las mismas con el resto de nuestras herramientas.</p>

                            <h3 class="my-3">¿Cúantas palabras clave podré monitorizar? ¿Necesito una suscripción para cada perfil?</h3>
                            <p class="lead">El número depende de la suscripción adquirida pero podrá monitorizar las palabras clave de cualquier perfil que se encuentre añadido a su cuenta.</p>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="header" id="headingTwo">
                        <h2 class="mb-0">
                            <button class="btn btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                Reseñador
                            </button>
                        </h2>
                    </div>
                    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                        <div class="card-body">
                            <h2 class="gold">Usuario (Gana Dinero)</h2>

                            <h3 class="my-3">¿Cuánto ganaré publicando reseñas?</h3>
                            <p class="lead">Depende del nivel de Local Guide de la cuenta que utilices para publicar la reseña. En la siguiente tabla tienes la remuneración por reseña en función del nivel de Local Guide:</p>

                            <div class="table-responsive">
                                <table class="table table-dark">
                                    <thead>
                                        <tr>
                                            <th scope="col">Local Guide</th>
                                            <th scope="col" class="text-center">Nivel 1</th>
                                            <th scope="col" class="text-center">Nivel 2</th>
                                            <th scope="col" class="text-center">Nivel 3</th>
                                            <th scope="col" class="text-center">Nivel 4</th>
                                            <th scope="col" class="text-center">Nivel 5</th>
                                            <th scope="col" class="text-center">Nivel 6</th>
                                            <th scope="col" class="text-center">Nivel 7</th>
                                            <th scope="col" class="text-center">Nivel 8</th>
                                            <th scope="col" class="text-center">Nivel 9</th>
                                            <th scope="col" class="text-center">Nivel 10</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th scope="row">Pago</th>
                                            <td class="text-center">0,50€</td>
                                            <td class="text-center">0,60€</td>
                                            <td class="text-center">0,70€</td>
                                            <td class="text-center">0,80€</td>
                                            <td class="text-center">0,90€</td>
                                            <td class="text-center">1€</td>
                                            <td class="text-center">1,10€</td>
                                            <td class="text-center">1,30€</td>
                                            <td class="text-center">1,60€</td>
                                            <td class="text-center">2€</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            <h3 class="my-3">¿Cuándo y cómo recibiré mi dinero?</h3>
                            <p class="lead">Todos los pagos se realizan <strong>el 15 de cada mes</strong>, en caso de no ser <strong>día laborable</strong> se procederá al pago el día hábil anterior. Para poder recibir el pago <strong>debe realizar la petición de cobro en su panel de Créditos, donde también podrá ver todas las transacciones.</strong></p>

                            <img src="img/faqs/faqs6.png" class="img-fluid d-block mx-auto my-4">

                            <p class="lead">La cantidad mínima para poder solicitar un pago es de <strong>25€</strong>. Todos los pagos se realizan <strong>a través de Paypal</strong>. En caso de no contar con cuenta puede crear la misma en este enlace. Solo es posible solicitar el cobro de los créditos obtenidos por publicación o afiliación, no se permite solicitar el cobro de crédito comprados a través de la tienda.</p>

                            <h3 class="my-3">¿Puedo utilizar varias cuentas de Google para publicar opiniones?</h3>
                            <p class="lead">Solamente puedes utilizar una cuenta por dispositivo. Por ejemplo, puedes publicar desde el ordenador con una cuenta y desde tu móvil con otra distinta. Pero una vez que hayas publicado en un dispositivo solamente podrás volver a publicar en él con la misma cuenta.</p>

                            <img src="img/faqs/faqs7.png" class="img-fluid d-block mx-auto my-4">

                            <h3 class="my-3">¿Cuáles son los requisitos para que validen mi cuenta?</h3>
                            <p class="lead">La mayoría de las cuentas que hayan tenido un uso cotidiano dejando reseñas en otros negocios, tengan antigüedad y no contengan contenido inadecuado no tendrán problema alguno y serán validadas inmediatamente. También requerimos que a la par que se hace uso de la cuenta con Imperatool para ayudar a las empresas el usuario continúe en las siguientes semanas realizando un uso común.</p>

                            <h3 class="my-3">¿Puede Google borrarme la cuenta por publicar comentarios?</h3>
                            <p class="lead">No hay ningún motivo por el que Google pueda borrar tu cuenta. No puede diferenciar tus opiniones de las de otros clientes. En algunos casos, si no se siguen las indicaciones, pueden ocultar las reseñas que publiques por eso te pedimos que sigas las instrucciones que te mostramos en la web y en tu panel al pie de la letra para evitar problemas.</p>

                            <h3 class="my-3">¿Puedo ser expulsado de Imperatool?</h3>
                            <p class="lead">Si no cumples las normas y políticas, realizas malas prácticas o eliminas comentarios puedes ser expulsado perdiendo el saldo acumulado y con opción a una sanción legal y/o económica. Según la legislación vigente el usuario es el responsable legal de todos los comentarios que realice y como tal puede ser sancionado si realiza prácticas perjudiciales para Imperatool o cualquiera de sus asociados.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            show: false
        }
    },
    computed: {
     
    }
}
</script>