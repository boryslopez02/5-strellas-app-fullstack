<template>
    <h3>Navbar vue</h3>
</template>

<script>
export default {

}
</script>