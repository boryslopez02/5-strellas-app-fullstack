<template>
    <div class="affiliates py-5">
        <div class="container">
            <h1 class="text-center my-5">GUÍA DE PUBLICACIÓN DE RESEÑAS</h1>

            <div class="content">
                <h2 class="my-3">¿Cómo puedo empezar a publicar?</h2>
                <p class="lead">Puedes registrarte gratuitamente desde la dirección panel.imperatool.com o iniciar sesión con tus cuentas de Google y Facebook. Una vez registrado, desde el apartado de "Inicio" podrás añadir tus cuentas de Google para comenzar a publicar reseñas. Lo único que debes hacer antes de poder publicar reseñas es verificar tu correo para comprobar que la cuenta es real. Introduce el código que te enviamos por email y ya estarás listo para empezar a ganar dinero.</p>
                <a href="/register" class="btn btn-block mx-auto my-5">¡Únete es Gratis y Automático!</a>

                <h2 class="my-3">Proceso de publicación</h2>
                <p class="lead">Una vez hayas verificado tus cuentas ya puedes utilizarlas para publicar opiniones. Desde el apartado "Publicar" puedes seleccionar cualquiera de las cuentas verificadas y solicitar una reseña. Si hay opiniones disponibles para tu género y localización se te asignará una de ellas, en caso contrario puedes esperar a que te notifiquemos por correo cuando aparezca alguna nueva. Recuerda que desde el apartado "Inicio" bajo el encabezado de "Reseñas disponibles" te mostraremos todas las opiniones disponibles en ese momento para publicar con cualquiera de tus cuentas.<br> <strong>Recuerda siempre confirmar la publicación de la reseña haciendo click en el botón de "Reseña publicada".</strong> En caso contrario es posible que otro usuario publique la reseña y reciba los créditos correspondientes en tu lugar.</p>

                <h2 class="my-3">Recomendaciones y buenas prácticas</h2>
                <p class="lead">Google realiza constantemente labores de análisis y control sobre las opiniones por lo que te recomendamos seguir los siguientes pasos a la hora de publicar para asegurar que tus opiniones no sean eliminadas:</p>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item">Indicar correctamente tu localización al añadir tu cuenta de Google a Imperatool.*</li>
                    <li class="list-group-item">No publicar opiniones en ciudades o países en los que no residas o visites habitualmente.</li>
                    <li class="list-group-item">Utilizar una dirección IP distinta para cada cuenta.*</li>
                    <li class="list-group-item">No publicar más de 3 opiniones diarias desde la misma cuenta de Google.</li>
                    <li class="list-group-item">Añadir una imagen de perfil a tu cuenta.</li>
                    <li class="list-group-item">Ocultar las reseñas publicadas en tu perfil de Google.</li>
                </ul>
                <p class="mt-4 mb-5"><small>*Obligatorio</small></p>

                <h2 class="my-3">Información adicional y ayuda</h2>
                <p class="lead">Si tienes cualquier duda puedes contactar con nosotros mediante el correo <a href="/">hola@negocio5estrallas.com</a> y a traves del formulario o chat online de la web. También tienes el apartado de preguntas frecuentes en la siguiente dirección: <a href="/faqs">imperatool.com/faq</a></p>
            </div>
        </div>
    </div>
</template>