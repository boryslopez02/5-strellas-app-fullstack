<template>
    <div class="legal py-5">
        <div class="container">
            <h1 class="text-center my-5">AVISO LEGAL</h1>

            <div class="content">
                <p class="lead mb-3">Bienvenid@ a Imperatool.com te invitamos a conocer estos términos antes de facilitar tus datos personales.</p>

                <p class="lead my-3"><strong>Datos Identificativos</strong></p>

                <p class="lead"><strong>Responsable: Marco Lopez de Miguel</strong></p>

                <p class="lead"><strong>NIF/CIF: 49101456K</strong></p>

                <p class="lead"><strong>Dirección: C/Castillejos N6, 28944, Madrid</strong></p>

                <p class="lead"><strong>Email: hola@negocio5estrallas.com</strong></p>

                <p class="lead">En este espacio, el usuario, podrá encontrar toda la información relativa a los términos y condiciones legales que definen las relaciones entre los usuarios y Imperatool como responsable de esta web. Como usuario, es importante que conozcas estos términos antes de continuar tu navegación.
                <br><br>
                Como responsable de esta web, se asume el compromiso de procesar la información de sus usuarios y clientes con plenas garantías y cumplir con los requisitos nacionales y europeos que regulan la recopilación y uso de los datos personales de los usuarios.
                <br><br>
                Con el fin de mejorar el entendimiento y comprensión de todos los puntos la política de privacidad que incluye la recogida, uso y derecho sobre los datos puede acceder en su propia página de política de privacidad desde este enlace: <a href="/privacy">Política de privacidad</a>
                <br><br>
                IMPERATOOL ha adecuado esta web a las exigencias del Reglamento (UE) 2016/679 del Parlamento Europeo y del Consejo de 27 de abril de 2016 relativo a la protección de datos de las personas físicas en lo que respecta al tratamiento de datos personales y a la libre circulación de estos datos y por el que se deroga la Directiva 95/46/CE (RGPD), así como con la Ley 34/2002, de 11 de julio, de Servicios de la Sociedad de la Información y Comercio Electrónico (LSSICE o LSSI).
                <br><br>
                <strong>Condiciones generales de uso</strong>
                <br>
                Las presentes Condiciones Generales regulan el uso (incluyendo el mero acceso) a las páginas de web, integrantes del sitio web de IMPERATOOL incluidos los contenidos y servicios puestos a disposición en ellas. Toda persona que acceda a la web, https://Imperatool.com (“usuario”) acepta someterse a las Condiciones Generales vigentes en cada momento del portal https://Imperatool.com. También regulan el uso a otras páginas web de las que IMPERATOOL es titular, como son : https://panel.imperatool.com; https://tech-solutio.com
                <br><br>
                El sitio web permite la creación de forma gratuita de una cuenta cliente, con un nombre de usuario y una contraseña, que podrá realizarse pulsando en el botón “Registro”, ubicado en la parte superior derecha de la home de la web, pulsando después en el botón “Crear cuenta” o Utilizando uno de los servicios de login de Facebook o Google, facilitando los datos que se solicitan en el formulario, siendo el nombre de usuario el correo electrónico facilitado por el usuario y la contraseña la que él mismo elija, y previa lectura de los términos de uso, política de privacidad y condiciones de contratación, mediante el marcado la casilla de lectura y aceptación de tales términos.
                <br><br>
                El usuario tendrá acceso a los siguientes servicios según la modalidad de la cuenta, empresa o usuario, y posterior contratación deseada:
                </p>

                <ul class="list-group list-group-flush my-3">
                    <li class="list-group-item">Marketplace entre empresas y usuarios para el intercambio de experiencias sobre sus negocios en Maps. (Ambos)</li>
                    <li class="list-group-item">Seguimiento del posicionamiento de su perfil según palabras clave en GMaps. (Empresas)</li>
                    <li class="list-group-item">Posibilidad de contactar con todos los usuarios que han reseñado en los perfiles de GMaps. (Empresas)</li>
                    <li class="list-group-item">Realización de campañas de Marketing Online. (Empresas)</li>
                </ul>

                <p class="lead my-3">
                    Imperatool solo ejerce de intermediario en su servicio de Marketplace entre usuarios y empresas, descargando la responsabilidad de su uso en estos agentes. Imperatool oferta servicios adicionales indicados anteriormente de los que da un servicio directo a empresas.
                    <br><br>
                    <strong>Compromisos y obligaciones de los usuarios</strong>
                    <br><br>
                    El usuario queda informado, y acepta, que el acceso a la presente web no supone, en modo alguno, el inicio de una relación comercial con IMPERATOOL. De esta forma, el usuario se compromete a utilizar el sitio web, sus servicios y contenidos sin contravenir la legislación vigente, la buena fe y el orden público.
                    <br><br>
                    Queda prohibido el uso de la web, con fines ilícitos o lesivos, o que, de cualquier forma, puedan causar perjuicio o impedir el normal funcionamiento del sitio web. Respecto de los contenidos de esta web, se prohíbe:
                </p>


                <ul class="list-group list-group-flush my-3">
                    <li class="list-group-item">Su reproducción, distribución o modificación, total o parcial, a menos que se cuente con la autorización de IMPERATOOL como legítimo titular</li>
                    <li class="list-group-item">Cualquier vulneración de los derechos del prestador o de IMPERATOOL como legítimo titular</li>
                    <li class="list-group-item">Su utilización para fines comerciales o publicitarios.</li>
                </ul>

                <p class="lead my-3">En la utilización de la web, https://Imperatool.com y de las otras webs de las cuales IMPERATOOL es titular, el usuario se compromete a no llevar a cabo ninguna conducta que pudiera dañar la imagen, los intereses y los derechos de IMPERATOOL o de terceros o que pudiera dañar, inutilizar o sobrecargar los portales que impidiera, de cualquier forma, la normal utilización de la web.</p>

                <p class="lead my-3">
                    No obstante, el usuario debe ser consciente de que las medidas de seguridad de los sistemas informáticos en Internet no son enteramente fiables y que, por tanto IMPERATOOL no puede garantizar la inexistencia de malware u otros elementos que puedan producir alteraciones en los sistemas informáticos (software y hardware) del usuario o en sus documentos electrónicos y ficheros contenidos en los mismos aunque se ponen todos los medios necesarios y las medidas de seguridad oportunas para evitar la presencia de estos elementos dañinos.
                    <br><br>
                    <strong>Enlaces Externos</strong>
                    <br><br>
                    Las páginas web de IMPERATOOL proporcionan enlaces a otros sitios web propios y a contenidos que son propiedad de terceros tales como:
                </p>

                <ul class="list-group list-group-flush my-3">
                    <li class="list-group-item">Herramientas</li>
                    <li class="list-group-item">Contenidos de otros Blogs</li>
                </ul>

                <p class="lead my-3">
                    <strong>Exclusion de garantías y responsabilidad</strong>
                    Imperatool no otorga ninguna garantía ni se hace responsable, en ningún caso, de los daños y perjuicios de cualquier naturaleza que pudieran traer causa de:
                </p>

                <ul class="list-group list-group-flush my-3">
                    <li class="list-group-item">La falta de disponibilidad, mantenimiento y efectivo funcionamiento de las webs, o de sus servicios y contenidos.</li>
                    <li class="list-group-item">La existencia de malware, programas maliciosos o lesivos en los contenidos.</li>
                    <li class="list-group-item">El uso ilícito, negligente, fraudulento o contrario a este Aviso Legal.</li>
                    <li class="list-group-item">La falta de licitud, calidad, fiabilidad, utilidad y disponibilidad de los servicios prestados por terceros y puestos a disposición de los usuarios en el sitio web.</li>
                    <li class="list-group-item">El prestador no se hace responsable bajo ningún concepto de los daños que pudieran dimanar del uso ilegal o indebido de las presentes páginas web.</li>
                </ul>

                <p class="lead my-3">
                    <strong>Ley aplicable y jurisdicción</strong>
                    <br>
                    Con carácter general las relaciones entre IMPERATOOL con los usuarios de sus servicios telemáticos, presentes en esta web se encuentran sometidas a la legislación y jurisdicción españolas y a los tribunales de Madrid.
                    <br><br>
                    <strong>Contacto</strong>
                    <br>
                    En caso de que cualquier usuario tuviese alguna duda acerca de estas Condiciones legales o cualquier comentario sobre el portal https://Imperatool.com, por favor diríjase a legal@Imperatool.com. Este aviso legal ha sido actualizado por última vez el 07 de Febrero de 2019.
                    <br><br>
                    Documento revisa el 7 de Febrero de 2019
                    <br><br>
                    Puede obtener toda la información de nuestra política de privacidad desde este enlace: <a href="/privacy">Política de privacidad</a>
                </p>
            </div>
        </div>
    </div>
</template>