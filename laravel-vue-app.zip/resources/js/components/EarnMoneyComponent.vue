<template>
    <div class="earn-money py-5" id="earn-money">  
        <span class="glass"></span>
        <div class="row container justify-content-center justify-content-lg-start my-0 mx-auto px-0 py-5">
            <div class="col-12 col-lg-10 text-white my-5">
                <h1>Gana dinero <br>trabajando con nosotros</h1>
                <p class="lead">Publica reseñas, trae amigos, recomiéndanos a tus clientes</p>
                <a href="/guide" class="btn btn-warning mx-auto mx-lg-0">Deseo más información <span></span></a>
            </div>

            <div class="col-10 col-sm-8 col-md-6 col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <div class="card-head d-flex align-items-center mt-2 mb-4">
                            <img src="img/icons/earn-money/1.money.png" class="mr-2">
                            <h4>Ganar dinero publicando opiniones.</h4>
                        </div>
                        <p>Gana dinero publicando reseñas positivas en Google. Cuanto mayor sea tu nivel de Local Guide mayor beneficio obtendrás por cada publicación. Recibe el dinero cada mes directamente en tu cuenta de Paypal.</p>
                    </div>
                </div>
            </div>

            <div class="col-10 col-sm-8 col-md-6 col-lg-4 my-5 my-md-0">
                <div class="card">
                    <div class="card-body">
                        <div class="card-head d-flex align-items-center mt-2 mb-4">
                            <img src="img/icons/earn-money/2.refer.png" class="mr-2">
                            <h4>Obtén un 50% de las ventas refiriéndonos con link personal.</h4>
                        </div>
                        <p>Invita a tus amigos a registrarse con tu enlace de asociados y recibe un 50% del beneficio por cada compra que realicen durante todo el año.</p>
                    </div>
                </div>
            </div>

            <div class="col-10 col-sm-8 col-md-6 col-lg-4 my-md-5 my-lg-0">
                <div class="card">
                    <div class="card-body">
                        <div class="card-head d-flex align-items-center mt-2 mb-4">
                            <img src="img/icons/earn-money/3.gift.png" class="mr-2">
                            <h4>Obtén descuentos exclusivos promocionándonos.</h4>
                        </div>
                        <p>Mejora la valoración de tus clientes con nosotros y obtén un descuento del 20% en cada compra. Regístrate ahora, solicita la verificación de tu perfil de agencia y comienza a trabajar con nosotros con beneficios exclusivos.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>     
</template>

<script>
export default {

}
</script>