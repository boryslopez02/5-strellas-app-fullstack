<template>
    <div class="guide py-5">
        <div class="container">
            <h1 class="text-center my-5">AFILIATE Y GANA EL 50% MES A MES!</h1>

            <div class="content">
                <h2 class="my-3">¿Cuánto ganaré como socio de Imperatool?</h2>

                <p class="lead">En Imperatool queremos trabajar juntos por ello <strong>la figura de afiliado es considerada un socio con el que compartimos los beneficios</strong>. Como ingenieros <strong>nos dedicamos a la mejora de nuestro sistema cada día aportando valor con nuevos servicios y mejorando los existentes</strong> mientras que tu <strong>como socio te encargas de la parte de marketing</strong> consiguiendo ayudar a centenares de empresas por lo que vas a obtener el <strong>50% de todas las ventas de packs y de forma mensual.</strong></p>

                <p class="lead my-3"><strong>Nueva tabla de comisión - ¿Sencillo?</strong></p>

                <table class="table table-dark">
                    <thead>
                        <tr>
                            <th scope="col">Local Guide</th>
                            <th scope="col">50%</th>
                        </tr>
                    </thead>
                </table>

                <p class="lead my-3"><strong>Ejemplo de venta Pack Imperator, esto mes a mes</strong></p>

                <table class="table">
                    <thead>
                        <tr class="text-center">
                            <th scope="col" class="bg-warning text-dark">50% Socio - 49,45€/mes</th>
                            <th scope="col" class="bg-success"><small class="text-white">15% Publicador</small></th>
                            <th scope="col" class="bg-info"><small class="text-white">20% Impuestos Ind.</small></th>
                            <th scope="col" class="bg-danger"><small class="text-white">15% Imperatool</small></th>
                        </tr>
                    </thead>
                </table>

                <a href="/register" class="btn btn-block mx-auto my-5">¡Únete es Gratis y Automático!</a>

                <p class="lead my-3"><strong>Desde el primer referido obtendrás un 50% del beneficio recurrente mes a mes. Además, en caso de contratar servicios adicionales obtendrás un 5% adicional!</strong> A tener en cuenta:</p>

                <p class="lead my-3"><strong>Analítica - ¿Por qué ganarás más con Imperatool?</strong></p>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item">El 83% de las empresas mantienen la suscripción entre 1-4 meses.</li>
                    <li class="list-group-item">El 21% de las empresas contrata créditos para servicios adicionales.</li>
                    <li class="list-group-item">El 87% de las empresas, que no se encontraban en 1ª posición, han mejorado su ranking en Maps</li>
                    <li class="list-group-item">El precio medio de venta es de 64,53€. Superior al pack intermedio.</li>
                    <li class="list-group-item">Añadir una imagen de perfil a tu cuenta.</li>
                    <li class="list-group-item">Ocultar las reseñas publicadas en tu perfil de Google.</li>
                </ul>

                <p class="lead my-3"><strong>Dando el máximo</strong></p>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item">50% de cada venta. Simple, sencillo, directo.</li>
                    <li class="list-group-item">La remuneración es recurrente mes a mes durante 12 meses por empresa.</li>
                    <li class="list-group-item">Estarás dando el mejor servicio a todos tus afiliados.</li>
                </ul>

                <h2 class="my-3">¿Cuales serán los resultados a nivel SEO para tus afiliados?</h2>
                <p class="lead">Casos desde el comienzo del uso de Imperatool. Sí, también tendrán gratuitamente este sistema de tracking ofrecido con nuestro partner SerpBook/Keyword.com</p>

                <div class="d-flex flex-column justify-content-center flex-md-row justify-content-md-around my-5">
                    <img src="/img/affiliates/1.png" class="img-fluid card card-body">
                    <img src="/img/affiliates/2.png" class="img-fluid card card-body my-4 my-md-0">
                </div>

                <h2 class="my-3">¿Cómo empiezo?</h2>
                <p class="lead">Para comenzar a obtener tu remuneración por afiliado tan solo has de <a href="/register">registrar una cuenta como publicador</a>, acceder en el menú lateral "Mi cuenta" y aceptar la solicitación de aceptación de contrato.</p>

                <img src="/img/affiliates/3.png" class="img-fluid d-block mx-auto my-4">

                <p class="lead">Tras la lectura del contrato y la aceptación del mismo puede hacer <strong>click en "Obtener link de socio"</strong>, automáticamente se activará una nueva sección donde podrá copiar su link de afiliado, los usuarios que se han registrado bajo su enlace y las transacciones realizadas por sus usuarios.</p>
                
                <img src="/img/affiliates/4.png" class="img-fluid d-block mx-auto my-4">

                <h2 class="my-3">¿Cómo y cuando recibo mis pagos?</h2>
                <p class="lead">Todos los pagos se realizan <strong>el 15 de cada mes</strong>, en caso de no ser <strong>día laborable</strong> se procederá al pago el día hábil anterior. Para poder recibir el pago <strong>ha realizar la petición de cobro en su panel de Créditos, donde también podrá ver todas las transacciones.</strong></p>

                <img src="/img/affiliates/5.png" class="img-fluid d-block mx-auto my-4">

                <p class="lead mb-4"><strong>La cantidad mínima</strong> para poder solicitar un pago es de <strong>25€. </strong> Todos los pagos se realizan <strong> a través de Paypal.</strong> En caso de no contar con cuenta puede crear la misma en este enlace. Solo es posible solicitar el cobro de los créditos obtenidos por publicación o afiliación, no se permite solicitar el cobro de crédito comprados a través de la tienda.</p>

                <h2 class="my-3">Soy Agencia, ¿puedo ser Socio Afiliado?</h2>
                <p class="lead">Sí, pero teniendo en cuenta que las agencias y los socios afiliados son <strong>dos figuras distintas una tiene un descuento para los clientes de la agencia y la otra una remuneración para los clientes que consigas para Imperatool</strong> por lo que no se puede acumular un descuento y obtener remuneración a la vez. En el caso de los <strong>socios afiliados la entrada al programa es automática</strong> y se rigen por los términos aquí indicados, en el caso de <strong>las agencias han de enviar una solicitud para obtener un descuento del 20% en todos nuestros servicios.</strong> Es importante tener en consideración:</p>

                <ul class="list-group list-group-flush">
                    <li class="list-group-item"><strong>La agencia</strong> mantiene sus clientes y son responsables de la gestión de sus perfiles dentro de Imperatool.</li>
                    <li class="list-group-item"><strong>Los socios afiliados</strong> invitan a empresas/usuarios a registrarse pasando a ser directamente clientes de Imperatool.</li>
                    <li class="list-group-item">Si una agencia desea acceder a la remuneración de socios afiliados podrá realizarlo invitando a la empresa a que gestione y realice todos los trámites directamente con Imperatool.</li>
                    <li class="list-group-item">No se permite la opción de creación de múltiples cuentas para la gestión de perfiles individuales por parte de una agencia.</li>
                </ul>

                <p class="lead text-center my-5"><strong>Toda empresa y/o usuario debe de aceptar nuestro <a href="/legal">Aviso Legal</a> y nuestra <a href="/privacy">Política de Privacidad</a> para poder navegar en nuestra web y/o usar nuestros servicios.</strong></p>
            </div>
        </div>
    </div>
</template>