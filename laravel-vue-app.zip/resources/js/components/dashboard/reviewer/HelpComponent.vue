<template>
    <div class="help">
        <h4 class="my-4">Importante</h4>

        <div class="card card-body my-3">
            <h5>Recuerda confirmar o cancelar la publicación</h5>
            <p class="lead">No olvides pulsar el botón "Reseña Publicada" si la has realizado para que podamos actualizarla y otorgarte los créditos correspondientes. En caso de no querer realizarla utiliza el botón "Cambiar reseña" o "Seleccionar Perfil", si no lo haces la reseña se quedará asignada a tu cuenta y deberás esperar a que la actualicemos para poder pedir otra distinta.</p>

            <h5 class="mt-3">Utiliza tus datos exactos</h5>
            <p class="lead">Es importante que el nombre que aparece en tu cuenta de Imperatool coincida con el que aparece en Google junto con la reseña. Nuestro sistema lo toma en cuenta para comprobar las reseñas y si no son iguales puede haber problemas o retrasos para obtener tus créditos.</p>

            <h5 class="mt-3">Publica la reseña correctamente</h5>
            <p class="lead">El número de estrellas debe ser el indicado en el panel y el texto debe ser exacto tal cual se muestra. Al igual que con el nombre de su cuenta, el texto se toma en cuenta en la comprobación por lo que lo más sencillo es "copiar y pegar" la redacción que le mostramos.</p>

            <h5 class="mt-3">Revisa las recomendaciones</h5>
            <p class="lead">Ponemos a tu disposición una guía de publicación con una serie de recomendaciones técnicas para que tus reseñas sean de la mayor calidad posible y no tengas problemas para ganar créditos. Puedes revisarla en: <a href="/guide">imperatool.com/guia-publicacion</a></p>
        </div>
    </div>
</template>