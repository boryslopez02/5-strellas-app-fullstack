<template>
    <div class="how-works py-5" id="how-works">  
        <div class="row container justify-content-center justify-content-lg-start my-0 mx-auto px-0 py-5">
            <div class="col-12 col-lg-10 text-white my-5">
                <h1>¿Cómo funciona?</h1>
            </div>
            <div class="col-10 col-sm-8 col-md-6 col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <div class="card-head d-flex align-items-center mt-2 mb-4">
                            <img src="img/icons/how-works/1.famous.png" class="mr-2">
                            <h4>Regístrate Gratis</h4>
                        </div>
                        <p>No tienes que añadir ninguna información de pago. Crea una cuenta o inicia sesión con Google o Facebook y tendrás acceso inmediato a nuestra plataforma. Además puedes solicitar 100 créditos gratuitos para probar el servicio.</p>
                    </div>
                </div>
            </div>
            <div class="col-10 col-sm-8 col-md-6 col-lg-4 my-5 my-md-0">
                <div class="card">
                    <div class="card-body">
                        <div class="card-head d-flex align-items-center mt-2 mb-4">
                            <img src="img/icons/how-works/2.business.png" class="mr-2">
                            <h4>Añade tu Negocio</h4>
                        </div>
                        <p>Añade tu empresa utilizando nuestro buscador que trabaja directamente con los datos de Google Maps. Si tienes más de un local puedes añadir todos sin ningún límite. Si no encuentras un negocio puedes añadirlo manualmente y nuestros técnicos completarán todos los campos restantes para que puedas empezar a recibir reseñas.</p>
                    </div>
                </div>
            </div>
            <div class="col-10 col-sm-8 col-md-6 col-lg-4 my-md-5 my-lg-0">
                <div class="card">
                    <div class="card-body">
                        <div class="card-head d-flex align-items-center mt-2 mb-4">
                            <img src="img/icons/how-works/3.star.png" class="mr-2">
                            <h4>Programa las opiniones</h4>
                        </div>
                        <p>Utiliza los créditos promocionales o contrata cualquier pack de reseñas o créditos y comienza a programar reseñas para tu negocio. Tú eliges la puntuación, el texto y la fecha de publicación. Puedes añadir imágenes a las opiniones y también seleccionar el género y localización del usuario que la publicará.</p>
                    </div>
                </div>
            </div>
            <div class="col-12 my-5">
                <a href="/register" class="btn btn-warning mx-auto">Recibe tu primera reseña gratis <span></span></a>
            </div>
        </div>
    </div>     
</template>

<script>
export default {

}
</script>