<template>
    <div class="about py-5" id="about">  
        <div class="row container justify-content-center justify-content-lg-start my-0 mx-auto px-0 py-5">
            <div class="col-12 col-lg-10 text-white my-5">
                <h1>Tú tienes el control <br> de tus opiniones</h1>
                <p class="lead">La mejora en tu reputación online, visibilidad y posicionamiento sobre tu competencia te traerá nuevos clientes. Evitará ataques de reputación y ayudará al posicionamiento. Envía a lo más bajo de la lista las reseñas negativas y destaca lo mejor de tu negocio.</p>
            </div>
            <div class="col-10 col-sm-8 col-md-6 col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <div class="card-head d-flex align-items-center mt-2 mb-4">
                            <img src="img/icons/control/1.organic.png" class="mr-2">
                            <h4>Orgánico y natural</h4>
                        </div>
                        <p>Recibir 10 comentarios en un mismo día no es natural, <strong>puedes gestionar las fechas en las que deseas tus publicaciones</strong>.</p>
                        <p class="m-0">Te damos acceso a un control total de la evolución de tu perfil para que puedas ver como mejora tu posicionamiento.</p>
                    </div>
                </div>
            </div>
            <div class="col-10 col-sm-8 col-md-6 col-lg-4 my-5 my-md-0">
                <div class="card">
                    <div class="card-body">
                        <div class="card-head d-flex align-items-center mt-2 mb-4">
                            <img src="img/icons/control/2.customizable.png" class="mr-2">
                            <h4>Personalizable y configurable</h4>
                        </div>
                        <p class="m-0">Elige la puntuación de cada comentario y aumenta la naturalidad. Nuestro sistema recomendará según el análisis continuado de tu perfil cuando deberías variar las puntuaciones, aunque por supuesto todo queda bajo tu control.</p>
                    </div>
                </div>
            </div>
            <div class="col-10 col-sm-8 col-md-6 col-lg-4 my-md-5 my-lg-0">
                <div class="card">
                    <div class="card-body">
                        <div class="card-head d-flex align-items-center mt-2 mb-4">
                            <img src="img/icons/control/3.geolocated.png" class="mr-2">
                            <h4>Geolocalizadas</h4>
                        </div>
                        <p>A diferencia de otros proveedores nosotros sí geolocalizamos los usuarios.</p>
                        <p class="m-0">Es muy importante que los usuarios que comenten en tu perfil tengan un historial con la zona en la que se encuentra tu negocio. Esto aumenta su valor.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>     
</template>

<script>
export default {

}
</script>