<template>
    <div class="contact py-5" id="contact">
        <div class="row container justify-content-center justify-content-lg-start justify-content-xl-between my-0 mx-auto px-0 py-5">
            <div class="col-12 col-lg-10 text-white my-5">
                <h1>Contáctanos</h1>
                <p class="lead">Puede ponerse en contacto con nosotros en cualquier momento 😊, solo te pedimos que para poder seguir mejorando el servicio compruebe antes si su respuesta se encuentra resuelta en nuesto <b>FAQ de empresas o nuestro FAQ de usuarios.</b></p>
            </div>

            <div class="col-12 col-sm-10 col-lg-6 col-xl-4">
                <form action="" class="form">
                    <input type="text" class="form-control" placeholder="Nombre">
                    <input type="email" class="form-control my-4" placeholder="E-mail">
                    <textarea name="" rows="5" class="form-control" placeholder="Mensaje"></textarea>
                    <input type="submit" value="Enviar" class="btn btn-primary mt-4 mx-auto mx-lg-0">
                </form>
            </div>

            <div class="col-12 col-sm-10 col-lg-6 col-xl-7 mt-5 mt-lg-0">
                <div class="accordion" id="accordionExample">
                    <div class="card card-header header p-4">
                        <h2 class="m-0 text-white">Algunas de las preguntas más comunes</h2>
                    </div>
                    <div class="card">
                        <div class="card-header" id="headingOne" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            <h4 class="mb-0">¿Puedo eliminar o desactivar reseñas en Google My Business?</h4>
                        </div>

                        <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                            <div class="card-body">
                                Eliminar comentarios negativos de Google my business es prácticamente imposible. El servicio ofrecido de opiniones tiene una base de usuarios tan extendida que no es posible ni para una empresa tan grande el gestionar los millones de reclamaciones que se producen a diario en la plataforma. Aun así, le indicamos los pasos seguidos por nuestros técnicos para que cuenten con toda la información. Si tratan de contactar con cualquier sede local la respuesta obtenía será que el servicio solo se ofrece desde la sede matriz en EEUU por lo que le indicaran ponerse en contacto directamente con ellos. Superando la dificultad para contactar, las indicaciones son realizar la reclamación a través de los medios webs facilitados, es decir, denunciar la reseña en Google marcándola como inadecuada. Tampoco es posible desactivar la opción para que cualquier usuario pueda publicar su opinión sobre tu negocio.
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header" id="headingTwo" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                            <h4 class="mb-0">¿Puedo eliminar mi negocio de Google Maps o eliminar mi cuenta de Google My Business?</h4>
                        </div>
                        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                            <div class="card-body">
                                No, no es posible eliminar su perfil. En su panel tendrá lo opción de eliminar la relación del negocio con usted, pero no es posible dar de baja un perfil. Algunas de las técnicas probadas pasan por marcar el negocio como cerrado múltiples veces, pero esto no funciona. También, es posible que desee saber si puede exigir el borrado del perfil, la respuesta oficial es que son los usuarios o dueños los que dan de alta los negocios y aunque en Europa ahora existe el derecho al olvido solo es aplicable a personas particulares y no negocios por lo que no existe legislación que apoye el borrar la ficha de un negocio. Para poder combatir la mala puntuación o reputación, la mejor opción es adquirir opiniones para su perfil de My Business.
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header" id="headingThree" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                            <h4 class="mb-0">¿Cómo redactar ejemplos de respuestas a comentarios negativos?</h4>
                        </div>
                        <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                            <div class="card-body">
                                Ante la imposibilidad de eliminar comentarios negativos en Google, lo mejor es comprar reseñas y tratar de dar la mejor imagen respondiendo calmadamente, ofreciendo un contacto y una solución. En caso de no conocer el caso o saber que es un comentario falso pueden incluirlo, pero solo si lo saben seguro en caso contrario podrían enfadar al usuario. - Sentimos mucho que haya tenido una mala experiencia. Como siempre tratamos de ofrecer el mejor servicio y calidad por lo que nos gustaría se pusiera en contacto con nosotros para poder mejorar y compensarle de manera adecuada. Lo más probable es que con respuestas como estas el usuario no retire su opinión ni vuelta a ponerse en contacto, pero lo importante es que los usuarios que lleguen a su perfil vean que se encuentra dispuesto y atento.
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</template>