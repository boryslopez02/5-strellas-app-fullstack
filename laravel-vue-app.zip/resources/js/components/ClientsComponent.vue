<template>
    <div class="earn-clients py-5">  
        <span class="glass"></span>
        <div class="row container justify-content-center justify-content-lg-start my-0 mx-auto px-0 py-5">
            <div class="col-12 col-lg-10 text-white my-5">
                <h1>Reseñas para Google <br> My Business de Calidad</h1>
                <p class="lead m-0">💖 Gana ✚ clientes, 🥇 Posiciona tu negocio y ⚔️ Protégete de ataques de reputación.</p>
            </div>
            <div class="col-10 col-sm-8 col-md-6 col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <div class="card-head d-flex align-items-center mt-2 mb-4">
                            <img src="img/icons/business/1.people.png" class="mr-2">
                            <h4>Opiniones reales</h4>
                        </div>
                        <p>Comentarán en tu perfil usuarios reales. Todos los perfiles que publiquen han de cumplir estrictos requisitos y ser verificados previamente por nuestro equipo para comprobar que son cuentas muy activas, que tienen opiniones e historial pasado suficiente.</p>
                    </div>
                </div>
            </div>

            <div class="col-10 col-sm-8 col-md-6 col-lg-4 my-5 my-md-0">
                <div class="card">
                    <div class="card-body">
                        <div class="card-head d-flex align-items-center mt-2 mb-4">
                            <img src="img/icons/business/2.stopwatch.png" class="mr-2">
                            <h4>El momento</h4>
                        </div>
                        <p>No dejes que la competencia te quite clientes por no cuidar tu perfil online. Todos los negocios tienen en su zona al menos 2 negocios que se dedican a lo mismo y cuentan con mejor puntuación. Además, + del 90% de usuarios se fía totalmente de las reseñas de otros usuarios.</p>
                    </div>
                </div>
            </div>

            <div class="col-10 col-sm-8 col-md-6 col-lg-4 my-md-5 my-lg-0">
                <div class="card">
                    <div class="card-body">
                        <div class="card-head d-flex align-items-center mt-2 mb-4">
                            <img src="img/icons/business/3.no-risk.png" class="mr-2">
                            <h4>Sin riesgos</h4>
                        </div>
                        <p>No existe ningún riesgo de penalización. El único problema que puedes tener es el cómo gestionar todos los clientes nuevos que tendrás. Todas las opiniones son de usuarios reales que cumplen estrictos requisitos para poder trabajar con nosotros.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>     
</template>

<script>
export default {

}
</script>