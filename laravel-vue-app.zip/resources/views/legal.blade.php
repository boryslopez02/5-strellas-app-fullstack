@extends('layouts.app')

@section('title', 'Afiliados - Negocio 5 Estrellas')

@section('content')
    <!-- Navbar -->
    @include('includes.nav')

    <legal-component></legal-component>

    <footer-component></footer-component>
@endsection