@extends('layouts.app')

@section('title', 'Afiliados - Negocio 5 Estrellas')

@section('content')
    <!-- Navbar -->
    @include('includes.nav')

    <privacy-component></privacy-component>

    <footer-component></footer-component>
@endsection