

<?php $__env->startSection('title', 'Afiliados - Negocio 5 Estrellas'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Navbar -->
    <?php echo $__env->make('includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <legal-component></legal-component>

    <footer-component></footer-component>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/borysl/public_html/laravel8/resources/views/legal.blade.php ENDPATH**/ ?>