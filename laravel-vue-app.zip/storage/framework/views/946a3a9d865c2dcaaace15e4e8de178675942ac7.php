

<?php $__env->startSection('title', 'FAQS - Negocio 5 Estrellas'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Navbar -->
    <?php echo $__env->make('includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <faqs-component></faqs-component>

    <footer-component></footer-component>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\borys\resources\views/faqs.blade.php ENDPATH**/ ?>