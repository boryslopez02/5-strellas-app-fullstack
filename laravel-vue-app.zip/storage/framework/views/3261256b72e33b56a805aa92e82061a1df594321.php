<?php $__env->startSection('title', 'Dashboard - Gestión de Clientes'); ?>



    <?php $__env->startSection('sidebar-links'); ?>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('employee.dashboard')); ?>">Dashboard</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('employee.account')); ?>">Mi Cuenta</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('employee.managment-stories')); ?>">Gestión de Reseñas</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('employee.managment-payments')); ?>">Gestión de Pagos</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" href="<?php echo e(route('employee.managment-customers')); ?>">Gestión de Clientes</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('employee.managment-reviewers')); ?>">Gestión de Reseñadores</a>
        </li>
        <li class="nav-item mb-md-5 mt-md-auto">
            <a class="nav-link" href="<?php echo e(route('employee.help')); ?>">Ayuda y Soporte</a>
        </li>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('sidebar-links2'); ?>
        <li class="nav-item">
            <hr>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#">Redes Sociales</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();
                    document.querySelector('form.logout-form').submit();">
                <?php echo e(__('Salir')); ?>

            </a>

            <form action="<?php echo e(route('logout')); ?>" method="POST" class="d-none logout-form">
                <?php echo csrf_field(); ?>
            </form>
        </li>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('nav-content'); ?>
        <h1 class="h2 m-0">Gestión de Clientes</h1>

        <div class="btn-toolbar my-3 d-none d-md-block">
            <div class="btn-group">
                <a href="#" class="btn text-nowrap">Redes Sociales</a>
                <a class="btn text-nowrap" href="<?php echo e(route('logout')); ?>"
                    onclick="event.preventDefault();
                        document.querySelector('form.logout-form').submit();">
                    <?php echo e(__('Salir')); ?>

                </a>

                <form action="<?php echo e(route('logout')); ?>" method="POST" class="d-none logout-form">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
   
    <?php $__env->startSection('center-content'); ?>
        
        <!-- TABLA -->
        <h4 class="my-5">Clientes</h4>

        <table class="table table-responsive my-5">
            <thead class="text-center text-nowrap">
                <tr>
                    <th scope="col">ID Reseña</th>
                    <th scope="col">Usuario asignado</th>
                    <th scope="col">Email Local Guide</th>
                    <th scope="col">Email Contacto</th>
                    <th scope="col">País</th>
                    <th scope="col">Estatus</th>
                    <th scope="col">Estatus</th>
                </tr>
            </thead>
            <tbody class="text-center">
                <tr>
                    <th scope="row">001</th>
                    <td>Nombre 1</td>
                    <td>mail@mail.com</td>
                    <td>mail@mail.com</td>
                    <td>País</td>
                    <td>Estatus</td>
                    <td>Estatus</td>
                </tr>
                <tr>
                    <th scope="row">001</th>
                    <td>Nombre 1</td>
                    <td>mail@mail.com</td>
                    <td>mail@mail.com</td>
                    <td>País</td>
                    <td>Estatus</td>
                    <td>Estatus</td>
                </tr>
                <tr>
                    <th scope="row">001</th>
                    <td>Nombre 1</td>
                    <td>mail@mail.com</td>
                    <td>mail@mail.com</td>
                    <td>País</td>
                    <td>Estatus</td>
                    <td>Estatus</td>
                </tr>
            </tbody>
        </table>
        <!-- END TABLE -->
  
    <?php $__env->stopSection(); ?>
    
    <?php $__env->startSection('right-content'); ?>
        <div class="gallet">
            <b>Notificaciones</b>
        </div>
        
        <div class="gallet">
            <hr>
            <p class="lead">15 Nuevos Reseñadores</p>
            <hr>
            <p class="lead">25 Nuevos Clientes</p>
            <hr>
            <p class="lead">10 Solicitudes de Pago</p>
            <hr>
            <p class="lead">Se aproxima fecha de pago a reseñadores</p>
            <hr>
        </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard-layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-vue-app\resources\views/employee/managment-customers.blade.php ENDPATH**/ ?>