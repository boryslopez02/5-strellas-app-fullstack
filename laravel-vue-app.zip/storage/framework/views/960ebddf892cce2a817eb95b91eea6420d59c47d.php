<?php $__env->startSection('title', 'Negocio 5 Estrellas'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Navbar -->
    <?php echo $__env->make('includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Obtain reviews -->
    <obtain-reviews-component></obtain-reviews-component>

    <!-- About -->
    <about-component></about-component>

    <!-- Earn Clients -->
    <clients-component></clients-component>

    <!-- Our Plans -->
    <plans-component></plans-component>

    <!-- Individual Plans -->
    <individual-plans-component></individual-plans-component>

    <!-- How Works -->
    <how-works-component></how-works-component>

    <!-- Earn Money -->
    <earn-money-component></earn-money-component>

    <!-- Footer -->
    <footer-component></footer-component>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/borysl/public_html/laravel8/resources/views/index.blade.php ENDPATH**/ ?>