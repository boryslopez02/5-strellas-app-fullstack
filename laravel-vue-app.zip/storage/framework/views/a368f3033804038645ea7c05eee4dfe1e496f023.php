

<?php $__env->startSection('title', 'Tienda - Negocio 5 Estrellas'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Navbar -->
    <?php echo $__env->make('includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <span class="glass"></span>
    
    <div class="container py-5">
        <store-suscription-component></store-suscription-component>
    
        <store-packs-component></store-packs-component>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-vue-app\resources\views/shop.blade.php ENDPATH**/ ?>