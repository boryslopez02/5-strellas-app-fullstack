

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

    <div class="glass-light">

        <nav class="navbar navbar-light sticky-top px-2 d-md-none">
            <a class="navbar-brand mr-0 px-3" href="/">
                <img src="<?php echo e(asset('img/logo.png')); ?>" class="img-fluid">
            </a>
            <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
        </nav>

        <div class="container-fluid">
            <div class="row">
                <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse pb-3 position-fixed">
                    <div class="sidebar-sticky pt-3">
                        <ul class="nav flex-column">
                            <li class="nav-item d-none d-md-block">
                                <a href="/" c7lass="navbar-brand">
                                    <img src="<?php echo e(asset('img/logo.png')); ?>" class="img-fluid">
                                </a>
                            </li>
                            <?php echo $__env->yieldContent('sidebar-links'); ?>
                        </ul>
                        <ul class="nav flex-column d-md-none">
                            <?php echo $__env->yieldContent('sidebar-links2'); ?>
                        </ul>
                    </div>
                </nav>

                <div class="main-content col-md-9 ml-sm-auto col-lg-10 px-md-4">
                    <div class="d-flex justify-content-between flex-wrap align-items-center pt-3 pb-2 mb-3">
                        <?php echo $__env->yieldContent('nav-content'); ?>
                    </div>

                    <div class="row m-0 p-0">
                        <div class="col-12 col-lg-8 col-xl-9 order-2 order-md-1">
                            <?php echo $__env->yieldContent('center-content'); ?>
                        </div>

                        <div class="col-12 col-lg-4 col-xl-3 order-1 order-md-2">
                            <?php echo $__env->yieldContent('right-content'); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-vue-app\resources\views/dashboard-layout/dashboard.blade.php ENDPATH**/ ?>