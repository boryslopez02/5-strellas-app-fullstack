

    <?php $__env->startSection('sidebar-links'); ?>
        <li class="nav-item">
            <a class="nav-link active" href="#">Dashboard</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#">Mi Cuenta</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#">Mis Perfiles</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#">Herramientas SEO</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#">Mi Tienda</a>
        </li>
        <li class="nav-item mb-md-5 mt-md-auto">
            <a class="nav-link" href="#">Ayuda y Soporte</a>
        </li>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('sidebar-links2'); ?>
        <li class="nav-item">
            <hr>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#">Redes Sociales</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#">Referidos</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#">Salir</a>
        </li>
        <li class="nav-item px-2 my-1">
            <input class="form-control form-control-dark w-100" type="text" placeholder="Buscar" aria-label="Search">
        </li>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('nav-content'); ?>
        <h1 class="h2 m-0">Dashboard</h1>
        <div class="group">
            <input class="form-control d-none d-lg-block" type="text" placeholder="Buscar" aria-label="Search">
        </div>
        <div class="btn-toolbar my-3 d-none d-md-block">
            <div class="btn-group">
                <input class="form-control mx-3 d-lg-none" type="text" placeholder="Buscar" aria-label="Search">
                <a href="" class="btn text-nowrap">Redes Sociales</a>
                <a href="" class="btn text-nowrap">Referidos</a>
                <a href="" class="btn text-nowrap">Salir</a>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
   
    <?php $__env->startSection('center-content'); ?>
        <h4 class="my-3">Mis Perfiles</h4>

        <!-- CAROUSEL CARDS -->
        <div class="row mx-0 mb-5 p-0 justify-content-center">
            <div class="col-8 col-sm-6 col-xl-4 p-1">
                <div class="card">
                    <div class="card-body">
                        <h4 class="username">Bjlm99</h4>
                        <p class="email">startcodify@gmail.com</p>
                        <img src="img/profile-icon.png" class="img-fluid my-3">
                        <a href="" class="btn btn-warning">Editar</a>
                    </div>
                </div>
            </div>

            <div class="col-8 col-sm-6 col-xl-4 p-1 my-5 my-sm-0">
                <div class="card">
                    <div class="card-body">
                        <h4 class="username">Bjlm99</h4>
                        <p class="email">startcodify@gmail.com</p>
                        <img src="img/profile-icon.png" class="img-fluid my-3">
                        <a href="" class="btn btn-warning">Editar</a>
                    </div>
                </div>
            </div>

            <div class="col-8 col-sm-6 col-xl-4 p-1 my-sm-5 my-xl-0">
                <div class="card">
                    <div class="card-body">
                        <h4 class="username">Bjlm99</h4>
                        <p class="email">startcodify@gmail.com</p>
                        <img src="img/profile-icon.png" class="img-fluid my-3">
                        <a href="" class="btn btn-warning">Editar</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- TABLA -->
        <h4 class="my-5">Reseñas asignadas</h4>

        <table class="table table-responsive my-5">
            <thead class="text-center text-nowrap">
                <tr>
                    <th scope="col">ID Reseña</th>
                    <th scope="col">Negocio</th>
                    <th scope="col">Estrellas Por Asignar</th>
                    <th scope="col">Pago a Recibir</th>
                    <th scope="col">Fecha Limite</th>
                    <th scope="col">Estatus</th>
                </tr>
            </thead>
            <tbody class="text-center">
                <tr>
                    <th scope="row">001</th>
                    <td>Negocio XXXX</td>
                    <td>*****</td>
                    <td>Pago a Recibir</td>
                    <td>05/04/2021</td>
                    <td>Por Ejecutar</td>
                </tr>
                <tr>
                    <th scope="row">001</th>
                    <td>Negocio XXXX</td>
                    <td>*****</td>
                    <td>Pago a Recibir</td>
                    <td>05/04/2021</td>
                    <td>Por Ejecutar</td>
                </tr>
                <tr>
                    <th scope="row">001</th>
                    <td>Negocio XXXX</td>
                    <td>*****</td>
                    <td>Pago a Recibir</td>
                    <td>05/04/2021</td>
                    <td>Por Ejecutar</td>
                </tr>
            </tbody>
        </table>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('right-content'); ?>
        <div class="gallet">
            <b>Mi Billetera:</b>
            <h1>$72</h1>
        </div>
        
        <div class="gallet">
            <hr>
            <p class="lead">Lorem ipsum dolor sit amet consectetur adipisicing elit. Officia aperiam aut commodi minus alias, possimus dicta, quos error animi est quia sint praesentium repudiandae perferendis magnam ut accusamus tempore. Fugiat!</p>
            <hr>
        </div>
        
        <div class="gallet">
            <b>Descuento</b>
            <h1>10%</h1>
        </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard-layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-vue-app\resources\views/dashboard-reviewer.blade.php ENDPATH**/ ?>